package resttemplate;

import org.json.simple.JSONObject;
import org.testng.Assert;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class RestTemplateImplementation {
	
	@Test(priority=1)
	private static void getAllTest()
	{
	    int statuscode;
	    String responseBody;

	    RestAssured.baseURI = "http://services.groupkt.com/country/get/all";	    
		RequestSpecification httpRequest = RestAssured.given();
		Response response = httpRequest.request(Method.GET);
		
		statuscode = response.getStatusCode();
		responseBody = response.getBody().asString();
		
		Assert.assertEquals(200, statuscode);
		Assert.assertTrue(responseBody.contains("\"USA\""));
		Assert.assertTrue(responseBody.contains("\"GBR\""));
		Assert.assertTrue(responseBody.contains("\"DEU\""));
	}
	
	
	@Test(priority=2)
	private static void getIndividualCountryCodesDETest()
	{
	    int statuscode;
	    String responseBody;

	    RestAssured.baseURI = "http://services.groupkt.com/country/get/iso2code/DE";	    
		RequestSpecification httpRequest = RestAssured.given();
		Response response = httpRequest.request(Method.GET);
		
		statuscode = response.getStatusCode();
		responseBody = response.getBody().asString();
		
		Assert.assertEquals(200, statuscode);
		Assert.assertTrue(responseBody.contains("\"DEU\""));
	}

	@Test(priority=3)
	private static void getIndividualCountryCodesUSTest()
	{
	    int statuscode;
	    String responseBody;

	    RestAssured.baseURI = "http://services.groupkt.com/country/get/iso2code/US";	    
		RequestSpecification httpRequest = RestAssured.given();
		Response response = httpRequest.request(Method.GET);
		
		statuscode = response.getStatusCode();
		responseBody = response.getBody().asString();
		
		Assert.assertEquals(200, statuscode);
		Assert.assertTrue(responseBody.contains("\"USA\""));
	}
	
	@Test(priority=4)
	private static void getIndividualCountryCodesGBTest()
	{
	    int statuscode;
	    String responseBody;

	    RestAssured.baseURI = "http://services.groupkt.com/country/get/iso2code/GB";	    
		RequestSpecification httpRequest = RestAssured.given();
		Response response = httpRequest.request(Method.GET);
		
		statuscode = response.getStatusCode();
		responseBody = response.getBody().asString();
		
		Assert.assertEquals(200, statuscode);
		Assert.assertTrue(responseBody.contains("\"GBR\""));
	}
	
	@Test(priority=5)
	private static void getNonExistentTest()
	{
	    int statuscode;
	    String responseBody;

	    RestAssured.baseURI = "http://services.groupkt.com/country/get/iso2code/XYZ";	    
		RequestSpecification httpRequest = RestAssured.given();
		Response response = httpRequest.request(Method.GET);
		
		statuscode = response.getStatusCode();
		responseBody = response.getBody().asString();
		
		System.out.println(responseBody);
		Assert.assertTrue(responseBody.contains("\"No matching country found for requested code [XYZ].\""));
	}
	
	@Test(priority=6)
	private static void postNweCountryCodeTest()
	{
	    int statuscode;
	    String responseBody;

	    RestAssured.baseURI = "http://services.groupkt.com/country";	    
		RequestSpecification httpRequest = RestAssured.given();
		
		JSONObject requestParams = new JSONObject();
		requestParams.put("name", "Test Country"); 
		requestParams.put("alpha2_code", "TC");		 
		requestParams.put("alpha3_code", "TCY");
		
		httpRequest.header("Content-Type", "application/json");
		 
		httpRequest.body(requestParams.toJSONString());

		//Assumed /add as the post url
		Response response = httpRequest.post("/add");

		int statusCode = response.getStatusCode();
		Assert.assertEquals(statusCode, "201");

	}
	
}
