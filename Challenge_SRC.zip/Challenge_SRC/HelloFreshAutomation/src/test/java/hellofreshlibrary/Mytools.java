package hellofreshlibrary;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.Proxy;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.Proxy.ProxyType;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.Reporter;

public class Mytools {
	
	//----------------------------------------------------------------------------------------------------
	
	public static void WaitFor(long seconds)
	{
		try{
			int a[] = {1,2};
			Thread.sleep(1000*seconds);
			Reporter.log("Waitfor method from Mytools is called now");
			
		} 
		catch(Throwable t){
			t.printStackTrace();
		}		
	}
		
	//----------------------------------------------------------------------------------------------------
	
	public static void WaitTillElementIsVisible(WebDriver oBrowser, By oBy , long synctimeoutseconds )
	{
		Reporter.log("WaitTillElementIsVisible method from Mytools is called now");
		try{
			WebDriverWait oWait; // we use this for explicit synchronization
			oWait = new WebDriverWait(oBrowser, synctimeoutseconds);
			oWait.until(ExpectedConditions.presenceOfElementLocated(oBy));
		} 
		catch(Throwable t){
			t.printStackTrace();
		}		
	}
	
	//----------------------------------------------------------------------------------------------------
	
	public static FirefoxProfile getProfile()
	{
		try{
			 FirefoxProfile oProfile;
			 oProfile = new FirefoxProfile();
			 oProfile.setPreference("network.proxy.type", 0);
			 return oProfile;
		} 
		catch(Throwable t){
			t.printStackTrace();
			return null;
		}		
	}
	
	//----------------------------------------------------------------------------------------------------
	
	public static DesiredCapabilities getCapability()
	{
		try{
			DesiredCapabilities oCapability;
			Proxy oProxy;// interim variable
			
			oProxy = new Proxy();
			oProxy.setProxyType(ProxyType.DIRECT);
			
			oCapability = new DesiredCapabilities();//updating the interim variable as the capability of the browser
			oCapability.setCapability(CapabilityType.PROXY, oProxy);
			
			return oCapability;
		} 
		catch(Throwable t){
			t.printStackTrace();
			return null;
		}		
	}
	
	//----------------------------------------------------------------------------------------------------
	
	public static void Scroll_PageTo(WebDriver oBrowser,int x, int y)
	{
		try{
			JavascriptExecutor oJsEngine;
			String sJsCommand;
			
			sJsCommand = String.format("window.scrollTo(%d,%d)", x,(y+50));
			oJsEngine = (JavascriptExecutor) oBrowser;
			oJsEngine.executeScript(sJsCommand);
			
			System.out.println(x +"and"+ y);
		} 
		catch(Throwable t){
			t.printStackTrace();
			}		
	}
	
	//----------------------------------------------------------------------------------------------------
	
	public static Properties getPropertyValues(String sPropertyFile)
	{
		
		Reporter.log("getPropertyValues method from Mytools is called now");
		
		try{
			InputStream oFileReader;//
			Properties oProperties;
			//System.out.println(sPropertyFile);
			//check whether the file exists or not
			
			if(!(new File(sPropertyFile)).exists()){
				throw new Exception("Property File Not Found! "+ "File = "+sPropertyFile);
			}
			
			oFileReader = new FileInputStream(sPropertyFile);//read the input file
			oProperties = new Properties();//instantiate the oProperties object
			oProperties.load(oFileReader);//pass the input stream as input to the properties object
			
			return oProperties;
			
		} 
		catch(Throwable t){
			return null;
		}		
	}
	
	//-----------------------------------------------------------------------------------------------------
	
	public static String getDateTimeStamp() {
		
		Reporter.log("getDateTimeStamp method from Mytools is called now");
		
		Date oDate = new Date();
		SimpleDateFormat oDateFormat = new SimpleDateFormat("DD_MM_YYYY-hh_mm_ssa");//a here is to mention the am pm
		String sStamp;
		
		sStamp = oDateFormat.format(oDate);
		return sStamp;

	}
	
	//-----------------------------------------------------------------------------------------------------
	
	public static void captureScreenshot(WebDriver oBrowser) {
		
		Reporter.log("captureScreenshot method from Mytools is called now");
		
		File src= ((TakesScreenshot)oBrowser).getScreenshotAs(OutputType.FILE);
		
		try {
			FileUtils.copyFile(src, new File(System.getProperty("user.dir")+"//Screenshots//error.png"));
		} catch (IOException e) {			
			e.printStackTrace();
		}
	}
	
	//-----------------------------------------------------------------------------------------------------
	
	public static String getRandomEmail() {
		Reporter.log("getRandomEmail method from Mytools is called now");
		return "hf_challenge"+getDateTimeStamp()+"@hf.com";
	}
	
	//-----------------------------------------------------------------------------------------------------
	
	public static void sendKeys(WebDriver oBrowser, String xpath, String input) {
		Reporter.log("sendKeys method from Mytools is called now");
		WaitTillElementIsVisible(oBrowser, By.xpath(xpath), 120l);
		oBrowser.findElement(By.xpath(xpath)).sendKeys(input);
	}
	
	//-----------------------------------------------------------------------------------------------------
	
	public static void click(WebDriver oBrowser, String xpath) {
		Reporter.log("click method from Mytools is called now");
		WaitTillElementIsVisible(oBrowser, By.xpath(xpath), 120l);
		
		JavascriptExecutor jse = (JavascriptExecutor)oBrowser;
		jse.executeScript("arguments[0].click();", oBrowser.findElement(By.xpath(xpath)));
		
		//oBrowser.findElement(By.xpath(xpath)).click();
	}
	
	//------------------------------------------------------------------------------------------------------
	
	public static void selectfromdropdown(WebDriver oBrowser, String locator, String visibletext, String value, Integer index ) {
		
		Reporter.log("selectfromdropdown method from Mytools is called now");
		
		Select oSelect = new Select(oBrowser.findElement(By.xpath(locator)));
		
		if(visibletext=="" && value=="") {
			oSelect.selectByIndex(index);
		}else if(visibletext=="" && index==null) {
			oSelect.selectByValue(value);
		}else {
			oSelect.selectByVisibleText(visibletext);
		}
	}
	
	//--------------------------------------------------------------------------------------------------------
	
	public static boolean verifyElementPresent(WebDriver oBrowser, String locator) {
		Reporter.log("verifyElementPresent method from Mytools is called now");
		boolean status = false;
		
		WaitTillElementIsVisible(oBrowser, By.xpath(locator), 120l);
		
		if(oBrowser.findElements(By.xpath(locator)).size()>0) {
			status = true;
		}
		
		return status;
		
	}
	
	//-----------------------------------------------------------------------------------------------------------
	
	public static boolean loggedInHomePageAssertion(WebDriver oBrowser) {
		//I just got to know from Giulia that i have to write script for ff as well - just added this wait as ff is reacting very fast(agrees not the best solution but wrt the time constraints)
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		Reporter.log("loggedInHomePageAssertion method from Mytools is called now");
		Properties loggedinHomePageProperties = Mytools.getPropertyValues(System.getProperty("user.dir")+"//Locators//LoggedinHomePage.properties");
		Boolean status = false;
		Boolean status1 =  oBrowser.getCurrentUrl().contains("controller=my-account");
		Boolean status2 = Mytools.verifyElementPresent(oBrowser, loggedinHomePageProperties.getProperty("lhp_signoutbtn"));
		Boolean status3 = Mytools.verifyElementPresent(oBrowser, loggedinHomePageProperties.getProperty("lhp_accoutinfotxt"));
		Boolean status4 = Mytools.verifyElementPresent(oBrowser, loggedinHomePageProperties.getProperty("lhp_myaccounttxt"));
		
		if(status1&&status2&&status3&&status4) {
			status = true;
		}
		
		return status;
	}
	
	//-----------------------------------------------------------------------------------------------------------
	
	public static String getText(WebDriver oBrowser, String locator) {
		Reporter.log("getText method from Mytools is called now");
		return oBrowser.findElement(By.xpath(locator)).getText();
	}
	
	//-----------------------------------------------------------------------------------------------------------
	
	public static void scrollIntoView(WebDriver oBrowser, String locator) {
		Reporter.log("scrollIntoView method from Mytools is called now");
		JavascriptExecutor jse = (JavascriptExecutor)oBrowser;
		jse.executeScript("arguments[0].scrollIntoView(true);", oBrowser.findElement(By.xpath(locator)));
	}
	
	//---------------------------------------------------------------------------------------------------------------------
	
	public static void hoverAndClick(WebDriver oBrowser, String locator) {
		Reporter.log("hoverAndClick method from Mytools is called now");
		Actions actions = new Actions(oBrowser);
		WebElement element = oBrowser.findElement(By.xpath(locator));
		actions.moveToElement(element);		
		actions.click().build().perform();
	}
}
