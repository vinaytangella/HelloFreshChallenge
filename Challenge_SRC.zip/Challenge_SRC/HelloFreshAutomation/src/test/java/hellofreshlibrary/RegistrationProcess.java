package hellofreshlibrary;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Properties;

import org.openqa.selenium.WebDriver;

public class RegistrationProcess {
	
	Properties accountCreationPageproperties = Mytools.getPropertyValues(System.getProperty("user.dir")+"//Locators//AccountCreationPage.properties");
	ExcelOperations exceloperations = new ExcelOperations();
	
	public void registration(WebDriver oBrowser) throws IOException {
		HashMap<String, ArrayList<String>> exceldata = exceloperations.readFromExcel("HelloFresh_TestData.xlsx", "Registration");
		Mytools.click(oBrowser, accountCreationPageproperties.getProperty("acp_mrsradiobtn"));
		Mytools.sendKeys(oBrowser, accountCreationPageproperties.getProperty("acp_firstnametxtbox"), exceldata.get("row1").get(0));
		Mytools.sendKeys(oBrowser, accountCreationPageproperties.getProperty("acp_lastnametxtbox"), exceldata.get("row1").get(1));
		Mytools.sendKeys(oBrowser, accountCreationPageproperties.getProperty("acp_passwordtxtbox"), exceldata.get("row1").get(2));
		Mytools.selectfromdropdown(oBrowser, accountCreationPageproperties.getProperty("acp_dayselect"), "", "1", null);
		Mytools.selectfromdropdown(oBrowser, accountCreationPageproperties.getProperty("acp_yearselect"), "", "2000", null);
		Mytools.selectfromdropdown(oBrowser, accountCreationPageproperties.getProperty("acp_monthselect"), "", "1", null);
		Mytools.sendKeys(oBrowser, accountCreationPageproperties.getProperty("acp_companytxtbox"), exceldata.get("row1").get(3));
		Mytools.sendKeys(oBrowser, accountCreationPageproperties.getProperty("acp_address1txtbox"), exceldata.get("row1").get(4));
		Mytools.sendKeys(oBrowser, accountCreationPageproperties.getProperty("acp_address2txtbox"), exceldata.get("row1").get(5));
		Mytools.sendKeys(oBrowser, accountCreationPageproperties.getProperty("acp_citytxtbox"), exceldata.get("row1").get(6));
		Mytools.selectfromdropdown(oBrowser, accountCreationPageproperties.getProperty("acp_stateselect"), exceldata.get("row1").get(7), "", null);
		Mytools.sendKeys(oBrowser, accountCreationPageproperties.getProperty("acp_ziptextbox"), exceldata.get("row1").get(8));
		Mytools.sendKeys(oBrowser, accountCreationPageproperties.getProperty("acp_additionalinformationtextarea"), exceldata.get("row1").get(9));
		Mytools.sendKeys(oBrowser, accountCreationPageproperties.getProperty("acp_homephonetxtbox"), exceldata.get("row1").get(10));
		Mytools.sendKeys(oBrowser, accountCreationPageproperties.getProperty("acp_mobiletxtbox"), exceldata.get("row1").get(11));
		Mytools.sendKeys(oBrowser, accountCreationPageproperties.getProperty("acp_aliasaddresstxtbox"), exceldata.get("row1").get(12));
		Mytools.click(oBrowser, accountCreationPageproperties.getProperty("acp_registeraccountbtn"));
	}

}
