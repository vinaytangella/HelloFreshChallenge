package hellofreshlibrary;

import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.Reporter;

public class PlaceOrder {
	
	Properties ordercheckoutproperties = Mytools.getPropertyValues(System.getProperty("user.dir")+"//Locators//OrderCheckOutBegintoEnd.properties");
	
	public void placeorder(WebDriver oBrowser) throws InterruptedException {		
		Mytools.click(oBrowser, ordercheckoutproperties.getProperty("chkout_womenlink"));
		Mytools.click(oBrowser, ordercheckoutproperties.getProperty("chkout_searchproductdropdown"));
		Mytools.sendKeys(oBrowser, ordercheckoutproperties.getProperty("chkout_searchproductdropdown"), "faded short sleeve");
		Mytools.click(oBrowser, ordercheckoutproperties.getProperty("chkout_searchproductdropdown"));
		Mytools.click(oBrowser, ordercheckoutproperties.getProperty("chkout_searchbtn"));
		Thread.sleep(5000);
		Mytools.click(oBrowser, ordercheckoutproperties.getProperty("chkout_addtocartlnk"));
		Mytools.click(oBrowser, ordercheckoutproperties.getProperty("chkout_prcdtochkoutbtn"));
		Mytools.click(oBrowser, ordercheckoutproperties.getProperty("chkout_prcdtochkout_summarybtn"));
		Mytools.click(oBrowser, ordercheckoutproperties.getProperty("chkout_prcdtochkout_addressbtn"));
		Mytools.click(oBrowser, ordercheckoutproperties.getProperty("chkout_prcdtochkout_termschkbox"));
		Mytools.click(oBrowser, ordercheckoutproperties.getProperty("chkout_prcdtochkout_shippingbtn"));
		Mytools.click(oBrowser, ordercheckoutproperties.getProperty("chkout_paybybanklnk"));
		Mytools.click(oBrowser, ordercheckoutproperties.getProperty("chkout_confirmorderbtn"));
	}
	
	public boolean assertcheckout(WebDriver oBrowser) {
		boolean status = false;
		boolean status1 = Mytools.getText(oBrowser, ordercheckoutproperties.getProperty("chkout_orderconfirmation")).equalsIgnoreCase("ORDER CONFIRMATION");
		boolean status2 = Mytools.getText(oBrowser, ordercheckoutproperties.getProperty("chkout_ordercompletetxt")).equalsIgnoreCase("Your order on My Store is complete.");
		boolean status3 = Mytools.verifyElementPresent(oBrowser, ordercheckoutproperties.getProperty("chkout_paymenttab"));
		boolean status4 = Mytools.verifyElementPresent(oBrowser, ordercheckoutproperties.getProperty("chkout_shippingtab"));
		boolean status5 = oBrowser.getCurrentUrl().contains("controller=order-confirmation");
		
		if(status1 && status2 && status3 && status4 && status5) {
			status = true;
		}
		return status;
	}

}
