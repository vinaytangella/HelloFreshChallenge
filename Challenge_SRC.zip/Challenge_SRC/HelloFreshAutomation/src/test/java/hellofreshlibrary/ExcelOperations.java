package hellofreshlibrary;

import java.util.ArrayList;
import java.util.HashMap;
import java.io.*;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelOperations {

	public HashMap<String, ArrayList<String>> readFromExcel(String filename, String sheetname) throws IOException {
		
		File excelFile = new File(System.getProperty("user.dir")+"//TestData//"+filename);
		HashMap<String, ArrayList<String>> excelcontent = new HashMap<>();
		XSSFWorkbook wb;
		wb = new XSSFWorkbook(new FileInputStream(excelFile));
		XSSFSheet sh = wb.getSheet(sheetname);
		XSSFRow row = sh.getRow(0);
		String cellContent;
		int colcount, rowcount= sh.getLastRowNum();

		for(int i=0;i<=rowcount;i++) {
			colcount = sh.getRow(i).getLastCellNum();
			ArrayList<String> content = new ArrayList<>();
			for(int j=0;j<colcount;j++) {
				cellContent = sh.getRow(i).getCell(j).toString();
				content.add(cellContent);
			}
			excelcontent.put("row"+i, content);
		}
		
		return excelcontent;
	}
}
