package hellofresh_casestudy;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import org.testng.TestNG;
import hellofreshlibrary.Mytools;
//This is an extra class i have added to provide an option of running tests with multiple suites(this will be useful especially when we have the framework grwing)
//This class is to run the tests from a driver script - I could not test this class as this is the last item i have worked on
public class MainDriverScript {

	private static String sMainInputFile = "AutomationInput.properties";
	
	//----------------------------------------------------------------------------------------------
	public static void main(String[] args) {
		try {
			Properties oProperties;
			String sSuiteXmlFile;
			String sOutputFolder;

			TestNG oTestng;
			List<String> oSuiteFiles;

			oProperties = Mytools.getPropertyValues(sMainInputFile);

			if (!new File(sMainInputFile).exists()) {
				throw new Exception("File Not Found!");
			}

			sSuiteXmlFile = oProperties.getProperty("SuiteFile").trim();

			if (sSuiteXmlFile == "") {
				throw new Exception("No Suite FileName Specified!");
			}

			sOutputFolder = "Results\\Result as on " + Mytools.getDateTimeStamp();
			oSuiteFiles = new ArrayList<String>();
			oSuiteFiles.add(sSuiteXmlFile);//if we have multiple Suitexml files decalred in the properties by 
			//comma separated values then we have to split the array and 

			oTestng = new TestNG();
			oTestng.setOutputDirectory(sOutputFolder);

			oTestng.setTestSuites(oSuiteFiles);
			oTestng.run();

			if (oTestng.getStatus() == 0) {
				System.out.println("Run = Passed");
			} else {
				System.out.println("Run = Failed");
				throw new Exception("Run Failed!");
			}

		} catch (Throwable t) {
			t.printStackTrace();
		}
	}

}
