package hellofresh_casestudy;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import hellofreshlibrary.*;
import org.testng.annotations.BeforeClass;
import org.apache.commons.io.FileUtils;
import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class TestCaseStudyHelloFresh {

	private WebDriver oBrowser;

	private ExcelOperations exceloperations = new ExcelOperations();
	private Properties oProperties;

	private RegistrationProcess registration = new RegistrationProcess();
	private PlaceOrder placeorder = new PlaceOrder();

	private String sIEDriver;
	private String sChromeDriver;
	private String sGeckoDriver;
	private String sUrl;
	private long lngPageLoadTimeOut;
	private long lngFindElementTimeOut;
	private String sBrType;

	public static Properties loginpageProperties, accountCreationPageproperties, loggedinHomePageProperties;

	String log4jConfPath = System.getProperty("user.dir") + "//log4j.properties";

	static final Logger logger = Logger.getLogger(TestCaseStudyHelloFresh.class);

	// -----------------Variables With Expected Value
	// ----------------------------------------------------

	// ----------------------------------------------------------------------------------------------------

	@SuppressWarnings("deprecation")
	@BeforeClass
	// @Parameters({"sBrType","IEDriver","ChromeDriver","PageLoadTimeOut","FindElementTimeOut",
	// "AppUrl"})
	public void Automation_Init() {
		BasicConfigurator.configure();
		logger.info("In Init Method");
		try {
			oProperties = Mytools.getPropertyValues("AutomationInput.properties");
			logger.info("Fetching properties from AutomationInout.properties");
			if (!new File("AutomationInput.properties").exists()) {
				throw new Exception("File Not Found!");
			}

			sBrType = oProperties.getProperty("BrType");
			sUrl = oProperties.getProperty("AppUrl");
			sIEDriver = oProperties.getProperty("IEDriver");
			sChromeDriver = oProperties.getProperty("ChromeDriver");
			sGeckoDriver = oProperties.getProperty("GeckoDriver");

			lngFindElementTimeOut = Long.valueOf(oProperties.getProperty("FindElementTimeOut"));
			lngPageLoadTimeOut = Long.valueOf(oProperties.getProperty("PageLoadTimeOut"));

			switch (sBrType.toLowerCase()) {
			case "ff":
				logger.info("Browser selected as Firefox");
				System.setProperty("webdriver.gecko.driver", sGeckoDriver);
				DesiredCapabilities capabilities = DesiredCapabilities.firefox();
				capabilities.setCapability("marionette", true);
				oBrowser = new FirefoxDriver(capabilities);
				break;

			case "ie":
				logger.info("Browser selected as IE");
				System.setProperty("webdriver.ie.driver", sIEDriver);
				oBrowser = new InternetExplorerDriver();
				break;

			case "chrome":
				logger.info("Browser selected as Chrome");
				System.setProperty("webdriver.chrome.driver", sChromeDriver);
				oBrowser = new ChromeDriver();
				break;

			default:
				logger.info("Incorrect browser has been selected - defaults to Firefox");
				System.err.println("Unknown Browser Type = " + sBrType);
				System.err.println("Setting default to Firefox ....");
				oBrowser = new FirefoxDriver();
				break;
			}

			logger.info("Preparing the browser");
			oBrowser.manage().window().maximize(); // This is the command to maximize the browser
			oBrowser.manage().deleteAllCookies(); // This will delete all the cookies
			oBrowser.manage().timeouts().pageLoadTimeout(lngPageLoadTimeOut, TimeUnit.SECONDS);// this method is used
																								// for navigation
			oBrowser.manage().timeouts().implicitlyWait(lngFindElementTimeOut, TimeUnit.SECONDS);
			oBrowser.get(sUrl);
			Mytools.WaitFor(5L); // Static method

		} catch (Throwable t) {
			logger.warn("Somethign went wrong in the init method");
			Assert.fail(t.getMessage(), t);
		}
	}

	// ----------------------------------------------------------------------------------------------------

	@AfterClass
	public void Automation_End() {
		try {
			oBrowser.close(); // To close the opened instance of the Firefox
		} catch (Throwable t) {
			logger.warn("Somethign went wrong in the Automation End method");
			Assert.fail(t.getMessage(), t);
		}
	}

	// ----------------------------------------------------------------------------------------------------

	@AfterMethod
	public void screenShot(ITestResult result) {
		if (ITestResult.FAILURE == result.getStatus()) {
			try {
				logger.info("Screenshot is being captured as tehre are one or more failed test cases");
				TakesScreenshot screenshot = (TakesScreenshot) oBrowser;
				File src = screenshot.getScreenshotAs(OutputType.FILE);
				FileUtils.copyFile(src,
						new File(System.getProperty("user.dir") + "//Screenshots//" + result.getName() + ".png"));
			} catch (Exception e) {
				logger.warn("Somethign went wrong in the Automation End method");
				System.out.println("Exception while taking screenshot " + e.getMessage());
			}
		}
	}

	// ----------------------------------------------------------------------------------------------------

	@Test(priority = 1)
	public void signInTest() throws IOException {
		logger.info("In first test case");
		try {
			Reporter.log("Url = " + oBrowser.getCurrentUrl());
			Reporter.log("<br>Title = " + oBrowser.getTitle());
			loginpageProperties = Mytools
					.getPropertyValues(System.getProperty("user.dir") + "//Locators//HomePage.properties");
			loggedinHomePageProperties = Mytools
					.getPropertyValues(System.getProperty("user.dir") + "//Locators//LoggedinHomePage.properties");
			Mytools.click(oBrowser, loginpageProperties.getProperty("hp_loginbtn"));
			String email = Mytools.getRandomEmail();
//			System.out.println(email);
			Mytools.sendKeys(oBrowser, loginpageProperties.getProperty("hp_create_emailtxtbox"), email);
			Mytools.click(oBrowser, loginpageProperties.getProperty("hp_createaccountbtn"));
			registration.registration(oBrowser);
			Assert.assertTrue(Mytools.loggedInHomePageAssertion(oBrowser));
			Mytools.click(oBrowser, loggedinHomePageProperties.getProperty("lhp_signoutbtn"));
		} catch (Throwable t) {
			logger.warn("Something went wrong in the first test case - please refer exception mesage");
			Mytools.captureScreenshot(oBrowser);
			System.out.println(t.getMessage());
		}
	}

	// -----------------------------------------------------------------------------------------------------

	@Test(priority = 2)
	public void logInTest() throws IOException {
		logger.info("In second test case");

		Properties loginpageProperties;

		try {
			Reporter.log("Url = " + oBrowser.getCurrentUrl());
			Reporter.log("<br>Title = " + oBrowser.getTitle());
			loginpageProperties = Mytools
					.getPropertyValues(System.getProperty("user.dir") + "//Locators//HomePage.properties");
			Mytools.click(oBrowser, loginpageProperties.getProperty("hp_loginbtn"));
			HashMap<String, ArrayList<String>> exceldata = exceloperations.readFromExcel("HelloFresh_TestData.xlsx", "Credentials");
			Mytools.sendKeys(oBrowser, loginpageProperties.getProperty("hp_emailtxtbox"),
					exceldata.get("row1").get(0));
			Mytools.sendKeys(oBrowser, loginpageProperties.getProperty("hp_passwordtxtbox"), exceldata.get("row1").get(1));
			Mytools.click(oBrowser, loginpageProperties.getProperty("hp_signinbtn"));
			Assert.assertTrue(Mytools.loggedInHomePageAssertion(oBrowser));
			Mytools.click(oBrowser, loggedinHomePageProperties.getProperty("lhp_signoutbtn"));
		} catch (Exception e) {
			logger.warn("Something went wrong in the second test case - please refer exception mesage");
			System.out.println(e.getMessage());
		}
	}

	// -----------------------------------------------------------------------------------------------------

	@Test(priority = 3)
	public void checkOutTest() throws IOException {

		logger.info("in third test case");
		Properties loginpageProperties;

		try {
			Reporter.log("Url = " + oBrowser.getCurrentUrl());
			Reporter.log("<br>Title = " + oBrowser.getTitle());
			loginpageProperties = Mytools
					.getPropertyValues(System.getProperty("user.dir") + "//Locators//HomePage.properties");
			Mytools.click(oBrowser, loginpageProperties.getProperty("hp_loginbtn"));
			Mytools.sendKeys(oBrowser, loginpageProperties.getProperty("hp_emailtxtbox"),
					"hf_challenge155_06_2018-11_04_33PM@hf.com");
			Mytools.sendKeys(oBrowser, loginpageProperties.getProperty("hp_passwordtxtbox"), "Qwerty");
			Mytools.click(oBrowser, loginpageProperties.getProperty("hp_signinbtn"));
			Assert.assertTrue(Mytools.loggedInHomePageAssertion(oBrowser));
			placeorder.placeorder(oBrowser);
			placeorder.assertcheckout(oBrowser);

		} catch (Exception e) {
			logger.info("somethign went wrong in the third test case - please refer to the exception message");
			System.out.println(e.getMessage());
		}
	}
}
